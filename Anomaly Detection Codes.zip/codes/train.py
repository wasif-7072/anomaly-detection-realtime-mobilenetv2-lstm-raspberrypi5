import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm import tqdm
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.utils.class_weight import compute_class_weight
from tensorflow.keras.utils import Sequence, to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, BatchNormalization
from tensorflow.keras.callbacks import (
    ModelCheckpoint, EarlyStopping,
    ReduceLROnPlateau, CSVLogger
)
import tensorflow as tf

# =============================================
# PATHS SETUP
# =============================================
base_path = os.getcwd()
features_path = os.path.join(base_path, 'features-extracted')
model_folder = os.path.join(base_path, 'train-model')
logs_folder = os.path.join(base_path, 'logs')
plots_folder = os.path.join(base_path, 'logs', 'plots')

os.makedirs(model_folder, exist_ok=True)
os.makedirs(plots_folder, exist_ok=True)

# =============================================
# SETTINGS
# =============================================
SEQUENCE_LENGTH = 20
BATCH_SIZE = 16
EPOCHS = 50
LEARNING_RATE = 0.001

# =============================================
# CLASS MAPPING
# =============================================
CLASS_NAMES = ['explosion', 'fight', 'normal', 'shoot']
NUM_CLASSES = len(CLASS_NAMES)

label_mapping = {
    'explosion': 0,
    'fight':     1,
    'normal':    2,
    'shoot':     3
}

print("=" * 60)
print("   ANOMALY DETECTION — LSTM TRAINING (FAST MODE)")
print("=" * 60)
print(f"Classes: {CLASS_NAMES}")
print(f"Sequence Length: {SEQUENCE_LENGTH} frames")
print(f"Batch Size: {BATCH_SIZE}")
print(f"Max Epochs: {EPOCHS}")
print("=" * 60)

# =============================================
# STEP 1: SEQUENCES BANANA FROM .NPY FILES
# =============================================
def create_sequences():
    all_sequences = []
    all_labels = []

    print("\n[STEP 1] Loading sequences from features...")
    print("-" * 60)

    for folder_name, label in label_mapping.items():
        feat_dir = os.path.join(features_path, folder_name)

        if not os.path.exists(feat_dir):
            print(f"[WARNING] {folder_name} folder not found — Skip")
            continue

        npy_files = [
            f for f in os.listdir(feat_dir)
            if f.endswith('.npy')
        ]

        if len(npy_files) == 0:
            print(f"[WARNING] {folder_name} no .npy files found!")
            continue

        seq_count = 0

        for npy_file in npy_files:
            npy_path = os.path.join(feat_dir, npy_file)
            features = np.load(npy_path)

            total_frames = len(features)

            if total_frames < SEQUENCE_LENGTH:
                continue

            # Sliding window — 50% overlap
            step = SEQUENCE_LENGTH // 2
            for i in range(0, total_frames - SEQUENCE_LENGTH + 1, step):
                sequence = features[i: i + SEQUENCE_LENGTH]
                if len(sequence) == SEQUENCE_LENGTH:
                    all_sequences.append(sequence)
                    all_labels.append(label)
                    seq_count += 1

        print(f"[{folder_name.upper()}] Sequences: {seq_count}")

    print("-" * 60)
    print(f"Total Sequences: {len(all_sequences)}")
    return np.array(all_sequences, dtype=np.float32), \
           np.array(all_labels)

# =============================================
# STEP 2: DATA GENERATOR
# =============================================
class FeatureDataGenerator(Sequence):
    def __init__(self, sequences, labels, batch_size=16,
                 augment=False):
        self.sequences = sequences
        self.labels = labels
        self.batch_size = batch_size
        self.augment = augment
        self.indices = np.arange(len(self.sequences))

    def __len__(self):
        return int(np.ceil(len(self.sequences) / self.batch_size))

    def on_epoch_end(self):
        np.random.shuffle(self.indices)

    def augment_sequence(self, sequence):
        if np.random.random() > 0.5:
            noise = np.random.normal(0, 0.01, sequence.shape)
            sequence = sequence + noise
        if np.random.random() > 0.5:
            scale = np.random.uniform(0.9, 1.1)
            sequence = sequence * scale
        return sequence

    def __getitem__(self, idx):
        batch_indices = self.indices[
            idx * self.batch_size: (idx + 1) * self.batch_size
        ]

        batch_x = self.sequences[batch_indices].copy()
        batch_y = self.labels[batch_indices]

        if self.augment:
            for i in range(len(batch_x)):
                batch_x[i] = self.augment_sequence(batch_x[i])

        batch_y_cat = to_categorical(batch_y, num_classes=NUM_CLASSES)

        return batch_x, batch_y_cat

# =============================================
# STEP 3: LOAD + SPLIT DATA
# =============================================
sequences, labels = create_sequences()

print("\n[INFO] Label Distribution:")
for cls_name, cls_idx in label_mapping.items():
    count = np.sum(labels == cls_idx)
    print(f"  {cls_name}: {count} sequences")

# Train / Val / Test — 70 / 15 / 15
train_seq, temp_seq, train_labels, temp_labels = train_test_split(
    sequences, labels,
    test_size=0.30,
    random_state=42,
    stratify=labels
)

val_seq, test_seq, val_labels, test_labels = train_test_split(
    temp_seq, temp_labels,
    test_size=0.50,
    random_state=42,
    stratify=temp_labels
)

print(f"\n[INFO] Data Split:")
print(f"  Training:   {len(train_seq)} sequences")
print(f"  Validation: {len(val_seq)} sequences")
print(f"  Testing:    {len(test_seq)} sequences")

# =============================================
# STEP 4: CLASS WEIGHTS
# =============================================
class_weights_array = compute_class_weight(
    class_weight='balanced',
    classes=np.unique(train_labels),
    y=train_labels
)
class_weight_dict = dict(enumerate(class_weights_array))

print(f"\n[INFO] Class Weights:")
for cls_name, cls_idx in label_mapping.items():
    print(f"  {cls_name}: {class_weight_dict[cls_idx]:.4f}")

# =============================================
# STEP 5: GENERATORS
# =============================================
train_generator = FeatureDataGenerator(
    train_seq, train_labels,
    batch_size=BATCH_SIZE,
    augment=True
)
val_generator = FeatureDataGenerator(
    val_seq, val_labels,
    batch_size=BATCH_SIZE,
    augment=False
)
test_generator = FeatureDataGenerator(
    test_seq, test_labels,
    batch_size=BATCH_SIZE,
    augment=False
)

# =============================================
# STEP 6: MODEL
# =============================================
print("\n" + "=" * 60)
print("[STEP 2] Building LSTM Model...")
print("=" * 60)

model = Sequential([
    LSTM(256, return_sequences=True,
         input_shape=(SEQUENCE_LENGTH, 1280)),
    BatchNormalization(),
    Dropout(0.4),

    LSTM(128, return_sequences=True),
    BatchNormalization(),
    Dropout(0.4),

    LSTM(64, return_sequences=False),
    BatchNormalization(),
    Dropout(0.3),

    Dense(128, activation='relu'),
    Dropout(0.3),

    Dense(64, activation='relu'),
    Dropout(0.2),

    Dense(NUM_CLASSES, activation='softmax')
])

model.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=LEARNING_RATE),
    loss='categorical_crossentropy',
    metrics=['accuracy']
)

model.summary()

# =============================================
# STEP 7: CALLBACKS
# =============================================
model_path = os.path.join(model_folder, 'best_model.h5')  # ← Fix
log_path = os.path.join(logs_folder, 'training_log.csv')

callbacks = [
    ModelCheckpoint(
        filepath=model_path,
        monitor='val_accuracy',
        verbose=1,
        save_best_only=True,
        mode='max'
    ),
    EarlyStopping(
        monitor='val_loss',
        patience=10,
        verbose=1,
        restore_best_weights=True
    ),
    ReduceLROnPlateau(
        monitor='val_loss',
        factor=0.5,
        patience=5,
        verbose=1,
        min_lr=1e-7
    ),
    CSVLogger(log_path, append=False)
]

# =============================================
# STEP 8: TRAINING
# =============================================
print("\n" + "=" * 60)
print("[STEP 3] Training Starting...")
print("=" * 60)

history = model.fit(
    train_generator,
    validation_data=val_generator,
    epochs=EPOCHS,
    callbacks=callbacks,
    class_weight=class_weight_dict,
    verbose=1
)

# =============================================
# STEP 9: PLOTS
# =============================================
print("\n[INFO] Saving Training Plots...")

plt.figure(figsize=(12, 4))

plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Val Accuracy')
plt.title('Model Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()
plt.grid(True)

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Val Loss')
plt.title('Model Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.grid(True)

plt.tight_layout()
plt.savefig(os.path.join(plots_folder, 'training_plots.png'))
plt.close()
print("[INFO] Plots saved: logs/plots/training_plots.png")

# =============================================
# STEP 10: TEST EVALUATION
# =============================================
print("\n" + "=" * 60)
print("[STEP 4] Evaluating on Test Set...")
print("=" * 60)

all_preds = []
all_true = []

for i in tqdm(range(len(test_generator)), desc="Testing"):
    x_batch, y_batch = test_generator[i]
    preds = model.predict(x_batch, verbose=0)
    all_preds.extend(np.argmax(preds, axis=1))
    all_true.extend(np.argmax(y_batch, axis=1))

all_preds = np.array(all_preds)
all_true = np.array(all_true)

print("\n[RESULTS] Classification Report:")
print(classification_report(
    all_true, all_preds,
    target_names=CLASS_NAMES
))

cm = confusion_matrix(all_true, all_preds)
print("[RESULTS] Confusion Matrix:")
print(cm)

plt.figure(figsize=(8, 6))
plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
plt.title('Confusion Matrix')
plt.colorbar()
tick_marks = np.arange(NUM_CLASSES)
plt.xticks(tick_marks, CLASS_NAMES, rotation=45)
plt.yticks(tick_marks, CLASS_NAMES)
for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):
        plt.text(j, i, format(cm[i, j], 'd'),
                 ha="center", va="center",
                 color="white" if cm[i, j] > cm.max()/2
                 else "black")
plt.ylabel('True Label')
plt.xlabel('Predicted Label')
plt.tight_layout()
plt.savefig(os.path.join(plots_folder, 'confusion_matrix.png'))
plt.close()
print("[INFO] Confusion Matrix saved!")

print("\n" + "=" * 60)
print("   TRAINING COMPLETE!")
print(f"   Best Model: train-model/best_model.h5")
print(f"   Plots:      logs/plots/")
print(f"   Log:        logs/training_log.csv")
print("=" * 60)