import cv2
import numpy as np
import os
import time
import threading
from collections import deque
from tensorflow.keras.models import load_model
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.models import Model

# =============================================
# PATHS SETUP
# =============================================
base_path = os.getcwd()
model_path = os.path.join(base_path, 'train-model', 'best_model.h5')

# =============================================
# SETTINGS
# =============================================
SEQUENCE_LENGTH    = 20
FRAME_SIZE         = (224, 224)
CLASS_NAMES        = ['EXPLOSION', 'FIGHT', 'NORMAL', 'SHOOT']
ANOMALY_CLASSES    = ['EXPLOSION', 'FIGHT', 'SHOOT']
CONFIDENCE_THRESHOLD = 0.80
WEBCAM_FPS         = 30
TARGET_FPS         = 10
FRAME_SKIP         = max(1, int(WEBCAM_FPS / TARGET_FPS))  # = 3

# =============================================
# COLORS — RGB Format
# =============================================
COLOR_NORMAL    = (0, 255, 0)     # Green
COLOR_ANOMALY   = (0, 0, 255)     # Red
COLOR_GATHERING = (255, 255, 0)   # Yellow
COLOR_INFO      = (255, 255, 255) # White

# =============================================
# ALARM SYSTEM
# =============================================
alarm_lock    = threading.Lock()
alarm_playing = False

def play_alarm():
    global alarm_playing
    try:
        import winsound
        while True:
            with alarm_lock:
                if not alarm_playing:
                    break
            winsound.Beep(1000, 500)  
            time.sleep(0.1)
    except Exception as e:
        print(f"[ALARM ERROR] {e}")

def start_alarm():
    global alarm_playing
    with alarm_lock:
        if not alarm_playing:
            alarm_playing = True
            t = threading.Thread(target=play_alarm, daemon=True)
            t.start()

def stop_alarm():
    global alarm_playing
    with alarm_lock:
        alarm_playing = False

# =============================================
# MODEL LOAD
# =============================================
print("=" * 60)
print("   AI REAL-TIME ANOMALY DETECTION — WEBCAM")
print("=" * 60)

if not os.path.exists(model_path):
    print(f"[ERROR] Model not found: {model_path}")
    exit()

print("[INFO] Loading LSTM Model...")
lstm_model = load_model(model_path)
print("[INFO] LSTM Model Loaded!")

print("[INFO] Loading MobileNetV2...")
base_model = MobileNetV2(
    weights='imagenet',
    include_top=False,
    input_shape=(224, 224, 3)
)
feature_extractor = Model(
    inputs=base_model.input,
    outputs=base_model.output
)
feature_extractor.trainable = False
print("[INFO] MobileNetV2 Loaded!")
print("=" * 60)

# =============================================
# GLOBAL VARIABLES
# =============================================
frames_queue   = deque(maxlen=SEQUENCE_LENGTH)
queue_lock     = threading.Lock()

current_label  = "Gathering frames..."
current_color  = COLOR_GATHERING
current_conf   = 0.0
current_class  = ""
is_anomaly     = False
is_running     = True

# Anomaly duration tracking
anomaly_start_time  = None
anomaly_duration    = 0.0

# =============================================
# AI THREAD — Background Prediction
# =============================================
def ai_worker():
    global current_label, current_color, current_conf
    global current_class, is_anomaly
    global anomaly_start_time, anomaly_duration

    while is_running:
        with queue_lock:
            if len(frames_queue) == SEQUENCE_LENGTH:
                sequence = np.array(list(frames_queue), dtype=np.float32)
            else:
                sequence = None

        if sequence is not None:
            try:
                input_seq    = np.expand_dims(sequence, axis=0)
                predictions  = lstm_model.predict(input_seq, verbose=0)[0]
                predicted_idx   = np.argmax(predictions)
                confidence      = float(predictions[predicted_idx])
                predicted_class = CLASS_NAMES[predicted_idx]

                if confidence >= CONFIDENCE_THRESHOLD:
                    if predicted_class in ANOMALY_CLASSES:
                        current_label  = f"ANOMALY Detected!"
                        current_color  = COLOR_ANOMALY
                        current_conf   = confidence
                        current_class  = predicted_class
                        is_anomaly     = True

                        # Anomaly duration track
                        if anomaly_start_time is None:
                            anomaly_start_time = time.time()
                        anomaly_duration = time.time() - anomaly_start_time

                        # Alarm start
                        start_alarm()

                    else:
                        current_label  = "NORMAL"
                        current_color  = COLOR_NORMAL
                        current_conf   = confidence
                        current_class  = "NORMAL"
                        is_anomaly     = False

                        # Anomaly khatam — reset
                        anomaly_start_time = None
                        anomaly_duration   = 0.0

                        # Alarm stop
                        stop_alarm()

                else:
                    current_label  = "Analyzing..."
                    current_color  = COLOR_GATHERING
                    current_conf   = confidence
                    is_anomaly     = False

            except Exception as e:
                print(f"[AI ERROR] {e}")

        time.sleep(0.05)

# =============================================
# FEATURE EXTRACTION
# =============================================
def extract_frame_feature(frame):
    img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, FRAME_SIZE)
    img = img.astype(np.float32)
    img = preprocess_input(img)
    img = np.expand_dims(img, axis=0)

    feature = feature_extractor.predict(img, verbose=0)
    feature = np.mean(feature, axis=(1, 2))
    return feature[0]

# =============================================
# DRAW OVERLAY
# =============================================
def draw_overlay(frame, label, color, conf, fps):
    h, w = frame.shape[:2]

    # Top banner — black background
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (w, 110), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)

    # Main label
    cv2.putText(frame, label,
                (15, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 1.1, color, 2)

    # Confidence bar background
    cv2.rectangle(frame, (15, 55), (w - 15, 75), (50, 50, 50), -1)

    # Confidence bar fill
    bar_width = int((w - 30) * min(conf, 1.0))
    cv2.rectangle(frame, (15, 55), (15 + bar_width, 75), color, -1)

    # Confidence text
    cv2.putText(frame, f"Confidence: {conf*100:.1f}%",
                (15, 95),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, COLOR_INFO, 1)

    # FPS — top right
    cv2.putText(frame, f"FPS: {fps:.1f}",
                (w - 120, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, COLOR_INFO, 1)

    # Anomaly duration — top right
    if is_anomaly and anomaly_duration > 0:
        cv2.putText(frame,
                    f"Duration: {anomaly_duration:.1f}s",
                    (w - 180, 55),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, COLOR_ANOMALY, 1)

    # Red border for anomaly
    if is_anomaly:
        thickness = 4
        cv2.rectangle(frame,
                      (0, 0), (w - 1, h - 1),
                      COLOR_ANOMALY, thickness)

        # ALERT text — bottom center
        alert_text = "!!! ALERT !!!"
        text_size  = cv2.getTextSize(
            alert_text, cv2.FONT_HERSHEY_SIMPLEX, 1.0, 2
        )[0]
        text_x = (w - text_size[0]) // 2
        cv2.putText(frame, alert_text,
                    (text_x, h - 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.0, COLOR_ANOMALY, 2)

    else:
        # Normal — bottom info
        cv2.putText(frame, "Press 'Q' to quit",
                    (15, h - 15),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, COLOR_INFO, 1)

    return frame

# =============================================
# WEBCAM OPEN
# =============================================
print("\n[INFO] Webcam opening...")
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("[ERROR] Webcam could not open!")
    exit()

# Webcam settings
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
cap.set(cv2.CAP_PROP_FPS, 30)

actual_w   = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
actual_h   = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
actual_fps = cap.get(cv2.CAP_PROP_FPS)

print(f"[INFO] Webcam Resolution: {actual_w}x{actual_h}")
print(f"[INFO] Webcam FPS: {actual_fps}")
print(f"[INFO] Frame Skip: {FRAME_SKIP} (Processing at {TARGET_FPS} FPS)")
print(f"[INFO] Confidence Threshold: {CONFIDENCE_THRESHOLD*100:.0f}%")
print(f"\n[INFO] Starting Real-Time Detection...")
print(f"[INFO] Press 'Q' to quit")
print("=" * 60)

# AI Thread start
ai_thread = threading.Thread(target=ai_worker, daemon=True)
ai_thread.start()

frame_count = 0
prev_time   = time.time()

# =============================================
# MAIN LOOP
# =============================================
while True:
    ret, frame = cap.read()
    if not ret:
        print("[ERROR] Frame not found!")
        break

    frame_count += 1

    # Feature extract 
    if frame_count % FRAME_SKIP == 0:
        feature = extract_frame_feature(frame)
        with queue_lock:
            frames_queue.append(feature)

    # FPS calculate
    curr_time = time.time()
    fps       = 1.0 / max(curr_time - prev_time, 1e-9)
    prev_time = curr_time

    # Overlay 
    display_frame = draw_overlay(
        frame.copy(),
        current_label,
        current_color,
        current_conf,
        fps
    )

    # Show
    cv2.imshow('AI Real-Time Anomaly Detection', display_frame)

    # Q press for quit
    if cv2.waitKey(1) & 0xFF == ord('q'):
        print("\n[INFO] User quit!")
        break

# =============================================
# CLEANUP
# =============================================
is_running = False
stop_alarm()
ai_thread.join(timeout=2)
cap.release()
cv2.destroyAllWindows()

print("\n" + "=" * 60)
print("   WEBCAM TEST COMPLETE!")
print("=" * 60)