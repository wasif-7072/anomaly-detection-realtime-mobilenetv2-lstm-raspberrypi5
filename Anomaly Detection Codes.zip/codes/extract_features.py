import os
import cv2
import numpy as np
from tqdm import tqdm
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.models import Model

# =============================================
# PATHS SETUP
# =============================================
base_path = os.getcwd()
frames_path = os.path.join(base_path, 'frames-extracted')
features_path = os.path.join(base_path, 'features-extracted')

categories = ['fight', 'shoot', 'normal', 'explosion']
FRAME_SIZE = (224, 224)
BATCH_SIZE = 32  # Ek baar mein sirf 32 frames RAM mein

# =============================================
# MOBILENETV2 LOAD
# =============================================
print("=" * 60)
print("   FEATURE EXTRACTION STARTING...")
print("=" * 60)
print("[INFO] Loading MobileNetV2...")

base_model = MobileNetV2(
    weights='imagenet',
    include_top=False,
    input_shape=(224, 224, 3)
)
feature_extractor = Model(
    inputs=base_model.input,
    outputs=base_model.output
)
feature_extractor.trainable = False
print("[INFO] MobileNetV2 Loaded!")
print("=" * 60)

# =============================================
# FRAME BATCH GENERATOR — Key Fix
# =============================================
def frame_batch_generator(frames_list, frm_dir, batch_size):
    """Frames load"""
    batch = []
    for img_name in frames_list:
        img_path = os.path.join(frm_dir, img_name)
        img = cv2.imread(img_path)

        if img is None:
            img = np.zeros((224, 224, 3), dtype=np.float32)
        else:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img = cv2.resize(img, FRAME_SIZE)
            img = img.astype(np.float32)
            img = preprocess_input(img)

        batch.append(img)

        if len(batch) == batch_size:
            yield np.array(batch, dtype=np.float32)
            batch = []  # Memory free

    # Remaining frames
    if len(batch) > 0:
        yield np.array(batch, dtype=np.float32)
        batch = []

# =============================================
# FEATURE EXTRACTION
# =============================================
def extract_features():
    total_saved = 0

    for category in categories:
        frm_dir = os.path.join(frames_path, category)
        feat_dir = os.path.join(features_path, category)
        os.makedirs(feat_dir, exist_ok=True)

        if not os.path.exists(frm_dir):
            print(f"[WARNING] {category} folder not found — Skip")
            continue

        images = [
            f for f in os.listdir(frm_dir)
            if f.lower().endswith('.jpg')
        ]

        if len(images) == 0:
            print(f"[WARNING] {category} frames not found!")
            continue

        # Video wise group
        video_frames_dict = {}
        for img in images:
            parts = img.split('_frame')
            if len(parts) >= 2:
                vid_name = parts[0]
                if vid_name not in video_frames_dict:
                    video_frames_dict[vid_name] = []
                video_frames_dict[vid_name].append(img)

        print(f"\n[{category.upper()}] — {len(video_frames_dict)} videos")
        print("-" * 60)

        cat_saved = 0

        for vid_name, frames_list in tqdm(
            video_frames_dict.items(),
            desc=f"Extracting {category}"
        ):
            # Sort frames
            try:
                frames_list.sort(
                    key=lambda x: int(
                        x.split('_frame')[1].split('.jpg')[0]
                    )
                )
            except:
                frames_list.sort()

            # Already exist — skip
            feat_file = os.path.join(feat_dir, f"{vid_name}.npy")
            if os.path.exists(feat_file):
                cat_saved += 1
                continue

            # batch by batch process
            
            all_features = []

            for batch in frame_batch_generator(
                frames_list, frm_dir, BATCH_SIZE
            ):
                batch_feat = feature_extractor.predict(
                    batch, verbose=0
                )
                # GlobalAveragePooling
                batch_feat = np.mean(batch_feat, axis=(1, 2))
                all_features.extend(batch_feat)
                del batch, batch_feat  # Memory free

            if len(all_features) == 0:
                continue

            features = np.array(all_features, dtype=np.float32)
            del all_features

            np.save(feat_file, features)
            cat_saved += 1

        print(f"[{category.upper()}] Features saved: {cat_saved} videos")
        total_saved += cat_saved

    print("\n" + "=" * 60)
    print(f"   FEATURE EXTRACTION COMPLETE!")
    print(f"   Total Videos Processed: {total_saved}")
    print("=" * 60)

# =============================================
# RUN
# =============================================
if __name__ == "__main__":
    extract_features()