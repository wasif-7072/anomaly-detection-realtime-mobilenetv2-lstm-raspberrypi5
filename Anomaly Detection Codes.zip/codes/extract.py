import cv2
import os
import numpy as np
from tqdm import tqdm

# =============================================
# PATHS SETUP
# =============================================
base_path = os.getcwd()
videos_path = os.path.join(base_path, 'video-dataset')
frames_path = os.path.join(base_path, 'frames-extracted')

# =============================================
# SETTINGS
# =============================================
categories = ['fight', 'shoot', 'normal', 'explosion']
TARGET_FPS = 10
FRAME_SIZE = (224, 224)

# =============================================
# FRAME EXTRACTION FUNCTION
# =============================================
def extract_frames():
    print("=" * 60)
    print("   FRAME EXTRACTION STARTING...")
    print("=" * 60)

    total_frames_saved = 0

    for category in categories:
        vid_dir = os.path.join(videos_path, category)
        frm_dir = os.path.join(frames_path, category)

        # Frames folder create 
        os.makedirs(frm_dir, exist_ok=True)

        # Video folder check k
        if not os.path.exists(vid_dir):
            print(f"\n[ERROR] '{category}' folder not found")
            continue

        # input videos
        video_files = [
            f for f in os.listdir(vid_dir)
            if f.lower().endswith(('.mp4', '.avi'))
        ]

        if len(video_files) == 0:
            print(f"\n[WARNING] '{category}' folder empty!")
            continue

        print(f"\n[{category.upper()}] — {len(video_files)} videos found")
        print("-" * 60)

        category_frames = 0

        # Progress bar 
        for video_file in tqdm(video_files, desc=f"Processing {category}"):
            video_path = os.path.join(vid_dir, video_file)
            cap = cv2.VideoCapture(video_path)

            # Video open check
            if not cap.isOpened():
                print(f"\n[ERROR] Video could not open: {video_file}")
                continue

            # Original FPS detect 
            original_fps = cap.get(cv2.CAP_PROP_FPS)
            if original_fps <= 0 or np.isnan(original_fps):
                original_fps = 30.0  # Default fallback

            # Frame skip calculate 
            frame_skip = max(1, int(round(original_fps / TARGET_FPS)))

            count = 0
            saved_count = 0
            video_name = os.path.splitext(video_file)[0]  

            while True:
                success, frame = cap.read()
                if not success:
                    break

                if count % frame_skip == 0:
                    # Resize 
                    resized_frame = cv2.resize(frame, FRAME_SIZE)

                    # Frame name
                    frame_filename = f"{category}_{video_name}_frame{saved_count:04d}.jpg"
                    save_path = os.path.join(frm_dir, frame_filename)

                    # Save karo
                    cv2.imwrite(save_path, resized_frame)
                    saved_count += 1

                count += 1

            cap.release()
            category_frames += saved_count

        print(f"[{category.upper()}] Total frames saved: {category_frames}")
        total_frames_saved += category_frames

    print("\n" + "=" * 60)
    print(f"   EXTRACTION COMPLETE!")
    print(f"   Total Frames Saved: {total_frames_saved}")
    print("=" * 60)

# =============================================
# RUN
# =============================================
if __name__ == "__main__":
    extract_frames()