import cv2
import numpy as np
import os
import time
import threading
from collections import deque
from tensorflow.keras.models import load_model
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.models import Model

# =============================================
# PATHS SETUP
# =============================================
base_path = os.getcwd()
model_path = os.path.join(base_path, 'train-model', 'best_model.h5')

# =============================================
# SETTINGS
# =============================================
SEQUENCE_LENGTH = 20
FRAME_SIZE = (224, 224)
CLASS_NAMES = ['EXPLOSION', 'FIGHT', 'NORMAL', 'SHOOT']
ANOMALY_CLASSES = ['EXPLOSION', 'FIGHT', 'SHOOT']
CONFIDENCE_THRESHOLD = 0.80  # 70% confidence chahiye

# =============================================
# COLORS — BGR Format
# =============================================
COLOR_NORMAL    = (0, 255, 0)     # Green
COLOR_ANOMALY   = (0, 0, 255)     # Red
COLOR_GATHERING = (255, 255, 0)   # Yellow
COLOR_INFO      = (255, 255, 255) # White

# =============================================
# MODEL LOAD
# =============================================
print("=" * 60)
print("   AI VIDEO ANOMALY DETECTION")
print("=" * 60)

if not os.path.exists(model_path):
    print(f"[ERROR] Model not found: {model_path}")
    exit()

print("[INFO] Loading LSTM Model...")
lstm_model = load_model(model_path)
print("[INFO] LSTM Model Loaded!")

print("[INFO] Loading MobileNetV2...")
base_model = MobileNetV2(
    weights='imagenet',
    include_top=False,
    input_shape=(224, 224, 3)
)
feature_extractor = Model(
    inputs=base_model.input,
    outputs=base_model.output
)
feature_extractor.trainable = False
print("[INFO] MobileNetV2 Loaded!")
print("=" * 60)

# =============================================
# VIDEO FILE SELECT
# =============================================
video_name = input("\nTest video name: ")
video_path = os.path.join(base_path, 'test-videos', video_name)

if not os.path.exists(video_path):
    print(f"[ERROR] Video not found: {video_path}")
    exit()

# =============================================
# GLOBAL VARIABLES
# =============================================
frames_queue   = deque(maxlen=SEQUENCE_LENGTH)
queue_lock     = threading.Lock()

current_label  = "Gathering frames..."
current_color  = COLOR_GATHERING
current_conf   = 0.0
is_anomaly     = False
is_running     = True

# =============================================
# AI THREAD — Background Prediction
# =============================================
def ai_worker():
    global current_label, current_color, current_conf, is_anomaly

    while is_running:
        with queue_lock:
            if len(frames_queue) == SEQUENCE_LENGTH:
                sequence = np.array(list(frames_queue), dtype=np.float32)
            else:
                sequence = None

        if sequence is not None:
            try:
                # LSTM prediction
                input_seq = np.expand_dims(sequence, axis=0)
                predictions = lstm_model.predict(input_seq, verbose=0)[0]

                predicted_idx = np.argmax(predictions)
                confidence = float(predictions[predicted_idx])
                predicted_class = CLASS_NAMES[predicted_idx]

                if confidence >= CONFIDENCE_THRESHOLD:
                    if predicted_class in ANOMALY_CLASSES:
                        current_label  = f"ANOMALY DETECTED!"
                        current_color  = COLOR_ANOMALY
                        current_conf   = confidence
                        is_anomaly     = True
                    else:
                        current_label  = "NORMAL"
                        current_color  = COLOR_NORMAL
                        current_conf   = confidence
                        is_anomaly     = False
                else:
                    current_label  = "Analyzing..."
                    current_color  = COLOR_GATHERING
                    current_conf   = confidence
                    is_anomaly     = False

            except Exception as e:
                print(f"[AI ERROR] {e}")

        time.sleep(0.05)

# =============================================
# FEATURE EXTRACTION FUNCTION
# =============================================
def extract_frame_feature(frame):
    img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, FRAME_SIZE)
    img = img.astype(np.float32)
    img = preprocess_input(img)
    img = np.expand_dims(img, axis=0)

    feature = feature_extractor.predict(img, verbose=0)
    feature = np.mean(feature, axis=(1, 2))
    return feature[0]

# =============================================
# DRAW OVERLAY FUNCTION
# =============================================
def draw_overlay(frame, label, color, conf, fps):
    h, w = frame.shape[:2]

    # Top banner
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (w, 100), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)

    # Main label
    cv2.putText(frame, label,
                (15, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 1.0, color, 2)

    # Confidence bar
    bar_width = int((w - 30) * conf)
    cv2.rectangle(frame, (15, 55), (w - 15, 75), (50, 50, 50), -1)
    cv2.rectangle(frame, (15, 55), (15 + bar_width, 75), color, -1)
    cv2.putText(frame, f"Confidence: {conf*100:.1f}%",
                (15, 92),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, COLOR_INFO, 1)

    # FPS
    cv2.putText(frame, f"FPS: {fps:.1f}",
                (w - 120, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, COLOR_INFO, 1)

    # Anomaly border — Red flashing
    if is_anomaly:
        cv2.rectangle(frame, (0, 0), (w-1, h-1), COLOR_ANOMALY, 4)

    # Bottom info
    cv2.putText(frame, "Press 'Q' to quit",
                (15, h - 15),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, COLOR_INFO, 1)

    return frame

# =============================================
# MAIN — VIDEO PLAYBACK
# =============================================
cap = cv2.VideoCapture(video_path)

if not cap.isOpened():
    print(f"[ERROR] Video could not open!")
    exit()

original_fps = cap.get(cv2.CAP_PROP_FPS)
if original_fps <= 0 or np.isnan(original_fps):
    original_fps = 30.0

total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
frame_skip = max(1, int(round(original_fps / 10)))
wait_time = max(1, int(1000 / original_fps))

print(f"\n[INFO] Video: {video_name}")
print(f"[INFO] FPS: {original_fps}")
print(f"[INFO] Total Frames: {total_frames}")
print(f"[INFO] Frame Skip: {frame_skip}")
print(f"\n[INFO] Starting... Press 'Q' to quit")
print("=" * 60)

# AI Thread start
ai_thread = threading.Thread(target=ai_worker, daemon=True)
ai_thread.start()

frame_count = 0
prev_time   = time.time()

while True:
    ret, frame = cap.read()
    if not ret:
        print("\n[INFO] Video end!")
        break

    frame_count += 1

    # Feature extract
    if frame_count % frame_skip == 0:
        feature = extract_frame_feature(frame)
        with queue_lock:
            frames_queue.append(feature)

    # FPS calculate
    curr_time = time.time()
    fps = 1.0 / max(curr_time - prev_time, 1e-9)
    prev_time = curr_time

    # Overlay draw
    display_frame = draw_overlay(
        frame.copy(),
        current_label,
        current_color,
        current_conf,
        fps
    )

    # Show
    cv2.imshow('AI Anomaly Detection — Video Test', display_frame)

    if cv2.waitKey(wait_time) & 0xFF == ord('q'):
        print("\n[INFO] User quit!")
        break

# =============================================
# CLEANUP
# =============================================
is_running = False
ai_thread.join(timeout=2)
cap.release()
cv2.destroyAllWindows()

print("\n" + "=" * 60)
print("   VIDEO TEST COMPLETE!")
print("=" * 60)